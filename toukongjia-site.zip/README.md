# 控盈 toukongjia
这是一个基于 Next.js 的中文首页示例，用于部署到 Vercel，并绑定域名 toukongjia.com。